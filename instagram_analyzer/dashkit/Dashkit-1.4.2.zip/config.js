module.exports =  {
  demoMode: true,
  colorScheme: 'light',
  navPosition: 'sidenav',
  navColor: 'default',
  sidebarSize: 'base'
}