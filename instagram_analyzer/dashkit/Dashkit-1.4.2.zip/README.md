# DASHKIT #

Dashkit Theme by Good Themes.

### Documentation ###

* Development documentation is available at `src/getting-started.html` (or `dist/getting-started.html` once you've compiled), or visit http://dashkit.goodthemes.co/getting-started.html.
* A full list components is available at `src/components.html` (or `dist/components.html` once you've compiled), or visit http://dashkit.goodthemes.co/components.html.

### Getting Started ###

The steps to compile and get started with development are covered in detail in documentation mentioned above, but the summary is:

- npm install -g gulp-cli
- npm install
- gulp

### Support ###

Good Themes is happy to provide support for issues. Shoot us an email at support@goodthemes.co and we'll get you squared away.